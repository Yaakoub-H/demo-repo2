package com.example.gameconnect3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    // false ; yellow , true ; red
    boolean[] vistedState = new boolean[9];
    int[] gameState = {0,0,0,0,0,0,0,0,0};
    boolean activePlayer = false;
    boolean checkCondition = false;

    public boolean CheckWinner(int[] gameState){
        if(gameState[0] == gameState[4] && gameState[4] == gameState[8]){
            // end game do something
            if(gameState[4] != 0) {
                checkCondition = true;
            }
        }
        if(gameState[2] == gameState[4] && gameState[4] == gameState[6]) {
            if(gameState[2] != 0) {
                checkCondition = true;
            }

        }
        if(gameState[0] == gameState[4] && gameState[4] == gameState[8]) {
            if(gameState[4] != 0) {
                checkCondition = true;
            }

        }
        if(gameState[2] == gameState[5] && gameState[5] == gameState[8]) {
            if(gameState[2] != 0) {
                checkCondition = true;
            }
        }
        if(gameState[1] == gameState[4] && gameState[4] == gameState[7]) {
            if(gameState[4] != 0) {
                checkCondition = true;
            }
        }
        if(gameState[8] == gameState[3] && gameState[4] == gameState[6]) {
            if(gameState[6] != 0) {
                checkCondition = true;
            }
        }
        if(gameState[0] == gameState[1] && gameState[1] == gameState[2]) {
            if(gameState[2] != 0) {
                checkCondition = true;
            }
        }
        if(gameState[3] == gameState[4] && gameState[4] == gameState[5]) {
            if(gameState[3] != 0) {
                checkCondition = true;
            }
        }
        if(gameState[6] == gameState[7] && gameState[7] == gameState[8]) {
            if(gameState[6] != 0) {
                checkCondition = true;
            }
        }
        return checkCondition == true;
    }

    public void dropIn(View view) {
        ImageView counter = (ImageView) view;
        int tappedCounter = Integer.parseInt(counter.getTag().toString());
        if (vistedState[tappedCounter]) {
            return;
        }
        counter.setTranslationY(-1000f);
        if (!activePlayer) {
            counter.setImageResource(R.drawable.yellow);
            gameState[tappedCounter] = 2;
            activePlayer = true;
        }
        else {
            counter.setImageResource(R.drawable.red);
            gameState[tappedCounter] = 1;
            activePlayer = false;
        }
        vistedState[tappedCounter] = true;
        counter.animate().translationYBy(1000f).rotation(3600).setDuration(900);

        if(CheckWinner(gameState)){
            if(checkCondition == true){
                TextView message = (TextView)findViewById(R.id.winnerMessage);
                message.setText("he has won!");
                LinearLayout layout = (LinearLayout) findViewById(R.id.playAgainLayout);
                layout.setVisibility(view.VISIBLE);
            }
        }
    }
    public void playAgain(View view){
        LinearLayout layout = (LinearLayout) findViewById(R.id.playAgainLayout);
        layout.setVisibility(view.INVISIBLE);
        vistedState = new boolean[9];
        for (int i = 0; i< gameState.length;i++){
            gameState[i] =0;
        }
        activePlayer = false;
        checkCondition = false;
        GridLayout gridLayout = (GridLayout) findViewById(R.id.gridLayout);
        for(int j = 0 ; j< gridLayout.getChildCount();j++){
            ((ImageView) gridLayout.getChildAt(j)).setImageResource(0);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}